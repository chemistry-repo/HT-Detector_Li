# mlsensing > mlsensing_640
https://universe.roboflow.com/yue-snlbi/mlsensing

Provided by a Roboflow user
License: MIT

