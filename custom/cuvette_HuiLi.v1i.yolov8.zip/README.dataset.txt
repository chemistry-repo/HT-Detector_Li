# cuvette_HuiLi > 2024-05-19 10:54pm
https://universe.roboflow.com/yue-snlbi/cuvette_huili

Provided by a Roboflow user
License: CC BY 4.0

